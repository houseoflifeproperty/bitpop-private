Chat.Models.Resource = Ember.Object.extend(Chat.Jsonable, {
    // Default attribute values
    show: null,
    status: null
});
