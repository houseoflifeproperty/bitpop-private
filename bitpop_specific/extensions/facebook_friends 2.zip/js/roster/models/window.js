Chat.Models.Window = Ember.Object.extend({
	tab_id: null
});